# Jeddah guide

Thirty Jeddah restaurants and twelve late night cafes, ranked best first,
in English and Arabic. Single self contained page, no build step.

## Publish on GitHub Pages (browser only)

1. Create a new **public** repository, for example `jeddah-guide`.
2. On the empty repo page choose **uploading an existing file** and drag
   `index.html` (and `.nojekyll`) in, then commit.
3. Go to **Settings, Pages**. Under Source pick **Deploy from a branch**,
   branch `main`, folder `/ (root)`, then Save.
4. About a minute later the site is live at
   `https://USERNAME.github.io/jeddah-guide/`

## Publish from a terminal instead

```bash
git init && git add . && git commit -m "Jeddah guide"
git branch -M main
git remote add origin https://github.com/USERNAME/jeddah-guide.git
git push -u origin main
```

Then do step 3 above once.

## Take it down

Settings, scroll to the bottom, Delete this repository. Or Settings, Pages,
set Source to None to unpublish while keeping the files.
